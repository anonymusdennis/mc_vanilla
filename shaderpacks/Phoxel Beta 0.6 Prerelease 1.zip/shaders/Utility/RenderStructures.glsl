#define RENDER_STRUCTURES

// Structures //
struct RayStr{
    vec3 Origin;
    vec3 Direction;

    // Color //
    vec3 Tint;
    vec3 Light;
};

struct MaterialStr{
    vec4 Color;
    float Emission;
    float Roughness;
    float F0;
};

struct HitDataStr{
    float t;
    vec3 Normal;
    MaterialStr Material;
};

// Structure Constants //
const MaterialStr BaseMaterial = MaterialStr(vec4(0.0), 0.0, 0.0, 0.0);