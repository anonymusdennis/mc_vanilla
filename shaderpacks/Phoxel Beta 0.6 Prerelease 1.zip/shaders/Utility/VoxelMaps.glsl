#define VOXELMAPS

// Structures //
struct Voxel {
    ivec3 TextureCoords;
    uint Tint;
};

// Buffers //
layout(std430, binding = 0) buffer VoxelMap0 {
    uint[] LOD0;
};

layout(std430, binding = 1) buffer VoxelMap1 {
    uint[] LOD1;
};

layout(std430, binding = 2) buffer VoxelMap2 {
    uint[] LOD2;
};

layout(std430, binding = 3) buffer VoxelMap3 {
    uint[] LOD3;
};

layout(std430, binding = 4) buffer VoxelTextureDataMap {
    Voxel[] VoxelTextureData;
};