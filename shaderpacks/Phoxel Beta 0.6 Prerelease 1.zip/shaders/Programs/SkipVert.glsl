#define SKIP

// Out //
out vec2 TextureUV;

// Code //
void main(){
    gl_Position = ftransform();
	TextureUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
}