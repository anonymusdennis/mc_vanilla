// Textures //
uniform sampler2D colortex0;

// In //
in vec2 TextureUV;

// Out //
/* RENDERTARGETS: 0 */
layout (location = 0) out vec4 FragColor;

void main(){
    FragColor = texture(colortex0, TextureUV);
}