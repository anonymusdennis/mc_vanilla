#version 430 compatibility

out vec2 TextureUV;
out vec2 LightMapUV;
out vec4 GlColor;
out vec3 VertexNormal;

uniform mat4 gbufferModelViewInverse;

void main() {
	gl_Position = ftransform();
	TextureUV = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	LightMapUV = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	GlColor = gl_Color;
    VertexNormal = mat3(gbufferModelViewInverse)*(gl_ModelViewMatrix*vec4(gl_Normal,1.0)).xyz;
}