// Denoising //
#version 430 compatibility
#include Utility/Settings.glsl
#if defined Render || (Similarity_Denoiser_SampleArea == 0)
    #include Programs/SkipFrag.glsl
#else
    #include Programs/Denoise.glsl
#endif