// Rendering //
#version 430 compatibility

// In //
in vec2 TextureUV;

// Out //
/* RENDERTARGETS: 7 */
layout (location = 0) out vec4 FragColor;
/*
    const int colortex0Format = RGB16F;
*/

// Code //
#include Programs/Phoxel.glsl